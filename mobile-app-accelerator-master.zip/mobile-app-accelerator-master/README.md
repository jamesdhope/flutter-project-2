# Antenna :: Flutter / Dart Mobile App Accelerator

Antenna is a mobile app written in the Flutter / Dart that authorises with IBM App ID and has a basic, extensible scaffold to invoke IBM Cloud Functions for access to services in the IBM Cloud.

### Language & Frameworks

Flutter is an open source framework by Google for building beautiful, natively compiled, multi-platform applications from a single codebase and is ideal for rapid mobile prototyping. Antenna is written using the *Domain Driven Design* framework for super clean code. The framework utilises *value-objects* as its atomic units to communicate with the different components and layers to provide super clean code that is maintainable and extensible. The app also uses Union Types and the Freezed package for immutable data classes.

### Quick-Start

#### Step 1: Install Flutter & Clone the Repo

* Please refer to the [documentation](https://docs.flutter.dev/get-started/install) to install Flutter
* Clone the repo

#### Step 2: Register IBM App ID & update Antenna with the IBM App ID application configuration

Register an IBM App ID in your IBM Cloud environment with the following configuration: 
* Create an application instance of type ```regularwebapp``` 
* Select for ```pre-production```
* Create a ```.env``` file as the root of the project with the following config:

```# .env
authorizationEndpointUrl=https://eu-gb.appid.cloud.ibm.com/oauth/v4/<your-custom-endpoint>/authorization
tokenEndpointUrl=https://eu-gb.appid.cloud.ibm.com/oauth/v4/<your-custom-endpoint>/token
clientId=<your-client-id>
clientSecret=<your-client-secret>
```

* Add the ```RedirectURL``` to the list of web redirect urls in App ID under Manage Authentication | Authentication Settings. 

#### Step 3: Register an IBMid Identity Provider using the Self-Service Provisioner

Register an IBMid Identity Provider using the [SSO Self-Service Provisioner](https://ies-provisioner.prod.identity-services.intranet.ibm.com/tools/sso/home.). 
* Supply the ```Client ID```,  ```Client Secret``` and ```Redirect URL``` from Step 2
* Enable the ```Authorisation Code``` Grant Type only
* Select for ```pre-production```

#### Step 4: Create and Expose a Function on IBM Cloud Functions

Create an Action on the IBM Cloud Function platform and then expose this Actioin via the API. Add the endpoint into the configuration into Antenna.

#### Step 5: Create a redirect url back to the oAuthWebView

* Register a Cloud Object Storage Bucket and note the ```public url``` for the url that is created.
* Add the ```public url``` to the list of web redirect urls in App ID under Manage Authentication | Authentication Settings. 
* Add the ```public url``` as the ```redirectUrl``` in ```.env```.

```# .env
authorizationEndpointUrl=https://eu-gb.appid.cloud.ibm.com/oauth/v4/<your-custom-endpoint>/authorization
tokenEndpointUrl=https://eu-gb.appid.cloud.ibm.com/oauth/v4/<your-custom-endpoint>/token
clientId=<your-client-id>
clientSecret=<your-client-secret>
redirectUrl=https://<cloud-object-storage-endpoint>.s3-web.ams03.cloud-object-storage.appdomain.cloud
```

#### Step 6: Run the app

To build and run the app locally, run: 
* ```flutter pub run build_runner watch --delete-conflicting-outputs```
* ```flutter run```

### Notes on Authorisation 

The oAuth flow adopted is the standard oAuth Authorisation flow. The oAuth Authorisation flow with PKCE provides a more secure mechanism for token exchange, however in this case the token is passed between mobile client and the backend via a WebView component and the benefits of an PKCE flow may be minimal. 

### Contact

<james.hope@ibm.com>