import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iot/application/functions/function_detail/functions_detail_bloc.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/injection.dart';

class FunctionDetail extends StatelessWidget {
  final CloudFunction cloudFunction;

  const FunctionDetail({Key? key, required this.cloudFunction})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        final bloc = getIt<FunctionsDetailBloc>();
        bloc.add(FunctionsDetailEvent.started(cloudFunction));
        return bloc;
        // == getIt<FunctionDetailBloc>()..add(FunctionDetailEvent.started(cloudFunction));
      },
      child: Scaffold(
        appBar: AppBar(),
        body: BlocBuilder<FunctionsDetailBloc, FunctionsDetailState>(
          builder: (context, state) {
            return state.when(
              initial: () => Container(),
              loading: () => Center(child: CircularProgressIndicator()),
              loadingSuccess: (result) => Center(
                child: Text(result),
              ),
              loadingFailure: (failure) => SafeArea(
                child: Text(
                    failure.map(unableToFetch: (_) => 'Something went wrong.')),
              ),
            );
          },
        ),
      ),
    );
  }
}
