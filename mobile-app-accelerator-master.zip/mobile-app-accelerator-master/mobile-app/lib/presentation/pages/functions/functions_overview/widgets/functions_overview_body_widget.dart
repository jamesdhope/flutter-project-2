import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iot/application/functions/functions_list/functions_list_bloc.dart';
import 'package:iot/injection.dart';
import 'package:iot/presentation/pages/functions/functions_overview/widgets/functions_card_widget.dart';

class FunctionsOverviewBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) =>
            getIt<FunctionsListBloc>()..add(FunctionsListEvent.started()),
        child: BlocBuilder<FunctionsListBloc, FunctionsListState>(
          builder: (context, state) {
            return state.map(
              initial: (_) => Container(),
              loading: (_) => const Center(
                child: CircularProgressIndicator(),
              ),
              loadingSuccess: (state) {
                return ListView.builder(
                  itemBuilder: (context, index) {
                    final function = state.functions[index];

                    return FunctionsCard(cf: function);
                  },
                  itemCount: state.functions.length,
                );
              },
              loadingFailure: (state) {
                return Scaffold();
              },
            );
          },
        ));
  }
}
