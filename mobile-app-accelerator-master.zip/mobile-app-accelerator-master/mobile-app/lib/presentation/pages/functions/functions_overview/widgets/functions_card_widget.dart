import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/presentation/routes/router.dart';

class FunctionsCard extends StatelessWidget {
  const FunctionsCard({
    Key? key,
    required this.cf,
  }) : super(key: key);

  final CloudFunction cf;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(cf.name),
      subtitle: Text(cf.endpoint),
      onTap: () => context.router.push(FunctionDetailRoute(cloudFunction: cf)),
    );
  }
}
