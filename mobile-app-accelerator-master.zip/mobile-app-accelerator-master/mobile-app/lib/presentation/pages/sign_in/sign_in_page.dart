import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iot/application/auth/sign_in_form/sign_in_form_bloc.dart';
import 'package:iot/injection.dart';
import 'package:iot/presentation/pages/sign_in/widgets/sign_in_form.dart';
import 'package:uni_links/uni_links.dart';

class SignInPage extends StatefulWidget {
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  void initState() {
    linkStream.listen((event) {
      print('Received $event');
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print('On sign in page');
    return Scaffold(
        backgroundColor: Colors.white,
        body: BlocProvider(
            create: (context) => getIt<SignInFormBloc>(),
            child: const SignInForm()));
  }
}
