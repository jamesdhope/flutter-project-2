import 'package:another_flushbar/flushbar_helper.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_keychain/flutter_keychain.dart';
import 'package:iot/application/auth/sign_in_form/sign_in_form_bloc.dart';
import 'package:iot/presentation/routes/router.dart';
import 'package:oauth_webauth/oauth_webauth.dart';
import 'package:one_context/one_context.dart';

class SignInForm extends StatefulWidget {
  const SignInForm({Key? key}) : super(key: key);

  @override
  State<SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<SignInForm> {
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SignInFormBloc, SignInFormState>(
      listener: (context, state) {
        state.authFailureOrSuccessOption.fold(
          () {},
          (either) {
            either.fold(
              (failure) {
                FlushbarHelper.createError(
                  message: failure.map(
                    // Use localized strings here in your apps
                    cancelledByUser: (_) => 'Cancelled',
                    serverError: (_) => 'Server error',
                    emailAlreadyInUse: (_) => 'Email already in use',
                    invalidEmailAndPasswordCombination: (_) =>
                        'Invalid email and password combination',
                  ),
                ).show(context);
              },
              (_) {
                context.router.push(FunctionsPageRoute());
              },
            );
          },
        );
      },
      builder: (context, state) {
        return Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('images/IBM_logo_pos_RGB.jpg'),
            Text('Client Engineering Mobile Accelerator'),
            Padding(
              padding: EdgeInsets.only(top: 30.0),
              child: ElevatedButton(
                child: Text('Sign in'),
                onPressed: () {
                  context
                      .read<SignInFormBloc>()
                      .add(SignInFormEvent.signInWithIbmButtonClicked(context));
                },
              ),
            )
          ],
        ));
      },
    );
  }
}
