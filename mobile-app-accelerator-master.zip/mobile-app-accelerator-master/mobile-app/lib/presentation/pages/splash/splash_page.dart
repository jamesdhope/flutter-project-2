import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iot/application/auth/auth_bloc.dart';
import 'package:iot/presentation/routes/router.dart';

class SplashPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print('Building splash page');
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        state.map(
          initial: (_) {
            print('Nothing');
          },
          authenticated: (_) {
            print('Authenticated');
            return context.router.push(FunctionsPageRoute());
          },
          unauthenticated: (_) {
            print('Pushing');
            return context.router.push(SignInPageRoute());
          },
        );
      },
      child: _PageWidget(),
    );
  }
}

class _PageWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('images/IBM_logo_pos_RGB.jpg'),
            Text('Client Engineering Mobile Accelerator'),
          ],
        ));
  }
}
