import 'package:auto_route/auto_route.dart';
import 'package:iot/domain/auth/i_auth_facade.dart';
import 'package:iot/presentation/routes/router.gr.dart';

class AuthenticationRequiredGuard extends AutoRedirectGuard {
  final IAuthFacade _authFacade;

  AuthenticationRequiredGuard(this._authFacade);

  @override
  void onNavigation(NavigationResolver resolver, StackRouter router) async {
    if (await _authFacade.isAuthenticated) {
      resolver.next();
    } else {
      router.push(SignInPageRoute());
    }
  }
}
