import 'package:auto_route/annotations.dart';
import 'package:iot/presentation/pages/functions/function_detail/function_detail.dart';
import 'package:iot/presentation/pages/sign_in/sign_in_page.dart';
import 'package:iot/presentation/pages/splash/splash_page.dart';

import '../pages/functions/functions_overview/functions_overview.dart';

export 'router.gr.dart';

@MaterialAutoRouter(routes: [
  AutoRoute(page: SplashPage, initial: true),
  AutoRoute(page: SignInPage),
  AutoRoute(page: FunctionsPage),
  AutoRoute(page: FunctionDetail)
])
class $Router {}
