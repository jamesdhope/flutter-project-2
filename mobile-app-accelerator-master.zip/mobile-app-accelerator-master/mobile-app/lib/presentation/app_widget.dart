import 'package:flutter/material.dart' hide Router;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iot/application/auth/auth_bloc.dart';
import 'package:iot/injection.dart';
import 'package:one_context/one_context.dart';

import 'routes/router.gr.dart';

class AppWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final router = Router();
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (_) =>
              getIt<AuthBloc>()..add(const AuthEvent.authCheckRequested()),
        ),
      ],
      child: MaterialApp.router(
          title: 'Client Engineering Mobile Accelerator',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(fontFamily: 'Plex').copyWith(
            primaryColor: Colors.blue[600],
            accentColor: Colors.blueAccent,
            appBarTheme: ThemeData.light().appBarTheme.copyWith(
                  brightness: Brightness.dark,
                  color: Colors.blue[600],
                  iconTheme: ThemeData.dark().iconTheme,
                ),
            floatingActionButtonTheme: FloatingActionButtonThemeData(
              backgroundColor: Colors.blue[900],
              foregroundColor: Colors.white,
            ),
            inputDecorationTheme: InputDecorationTheme(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          builder: OneContext.instance.builder,
          key: OneContext().navigator.key,
          routerDelegate: router.delegate(),
          routeInformationParser: router.defaultRouteParser()),
    );
  }
}
