import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/domain/functions/functions_failure.dart';
import 'package:iot/infrastructure/functions/file_functions_repository.dart';

part 'functions_detail_bloc.freezed.dart';
part 'functions_detail_event.dart';
part 'functions_detail_state.dart';

@injectable
class FunctionsDetailBloc
    extends Bloc<FunctionsDetailEvent, FunctionsDetailState> {
  // TODO: use interface
  final FunctionsRepository _functionsRepository;

  FunctionsDetailBloc(this._functionsRepository)
      : super(FunctionsDetailState.initial()) {
    on<FunctionsDetailEvent>(_onEvent);
  }

  void _onEvent(
      FunctionsDetailEvent event, Emitter<FunctionsDetailState> emit) async {
    await event.map(
      started: (e) async {
        emit(FunctionsDetailState.loading());
        final result = await _functionsRepository.callFunction(e.cloudFunction);
        result.fold(
            (failure) => emit(FunctionsDetailState.loadingFailure(failure)),
            (result) => emit(FunctionsDetailState.loadingSuccess(result)));
      },
    );
  }
}
