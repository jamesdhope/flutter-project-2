// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'functions_detail_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$FunctionsDetailEvent {
  CloudFunction get cloudFunction => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(CloudFunction cloudFunction) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(CloudFunction cloudFunction)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(CloudFunction cloudFunction)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $FunctionsDetailEventCopyWith<FunctionsDetailEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FunctionsDetailEventCopyWith<$Res> {
  factory $FunctionsDetailEventCopyWith(FunctionsDetailEvent value,
          $Res Function(FunctionsDetailEvent) then) =
      _$FunctionsDetailEventCopyWithImpl<$Res>;
  $Res call({CloudFunction cloudFunction});

  $CloudFunctionCopyWith<$Res> get cloudFunction;
}

/// @nodoc
class _$FunctionsDetailEventCopyWithImpl<$Res>
    implements $FunctionsDetailEventCopyWith<$Res> {
  _$FunctionsDetailEventCopyWithImpl(this._value, this._then);

  final FunctionsDetailEvent _value;
  // ignore: unused_field
  final $Res Function(FunctionsDetailEvent) _then;

  @override
  $Res call({
    Object? cloudFunction = freezed,
  }) {
    return _then(_value.copyWith(
      cloudFunction: cloudFunction == freezed
          ? _value.cloudFunction
          : cloudFunction // ignore: cast_nullable_to_non_nullable
              as CloudFunction,
    ));
  }

  @override
  $CloudFunctionCopyWith<$Res> get cloudFunction {
    return $CloudFunctionCopyWith<$Res>(_value.cloudFunction, (value) {
      return _then(_value.copyWith(cloudFunction: value));
    });
  }
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res>
    implements $FunctionsDetailEventCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
  @override
  $Res call({CloudFunction cloudFunction});

  @override
  $CloudFunctionCopyWith<$Res> get cloudFunction;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$FunctionsDetailEventCopyWithImpl<$Res>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, (v) => _then(v as _$_Started));

  @override
  _$_Started get _value => super._value as _$_Started;

  @override
  $Res call({
    Object? cloudFunction = freezed,
  }) {
    return _then(_$_Started(
      cloudFunction == freezed
          ? _value.cloudFunction
          : cloudFunction // ignore: cast_nullable_to_non_nullable
              as CloudFunction,
    ));
  }
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started(this.cloudFunction);

  @override
  final CloudFunction cloudFunction;

  @override
  String toString() {
    return 'FunctionsDetailEvent.started(cloudFunction: $cloudFunction)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Started &&
            const DeepCollectionEquality()
                .equals(other.cloudFunction, cloudFunction));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(cloudFunction));

  @JsonKey(ignore: true)
  @override
  _$$_StartedCopyWith<_$_Started> get copyWith =>
      __$$_StartedCopyWithImpl<_$_Started>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(CloudFunction cloudFunction) started,
  }) {
    return started(cloudFunction);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(CloudFunction cloudFunction)? started,
  }) {
    return started?.call(cloudFunction);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(CloudFunction cloudFunction)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(cloudFunction);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements FunctionsDetailEvent {
  const factory _Started(final CloudFunction cloudFunction) = _$_Started;

  @override
  CloudFunction get cloudFunction => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_StartedCopyWith<_$_Started> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$FunctionsDetailState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(String result) loadingSuccess,
    required TResult Function(FunctionsFailure functionsFailure) loadingFailure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Initial value) initial,
    required TResult Function(Loading value) loading,
    required TResult Function(LoadingSuccess value) loadingSuccess,
    required TResult Function(LoadingFailure value) loadingFailure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FunctionsDetailStateCopyWith<$Res> {
  factory $FunctionsDetailStateCopyWith(FunctionsDetailState value,
          $Res Function(FunctionsDetailState) then) =
      _$FunctionsDetailStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$FunctionsDetailStateCopyWithImpl<$Res>
    implements $FunctionsDetailStateCopyWith<$Res> {
  _$FunctionsDetailStateCopyWithImpl(this._value, this._then);

  final FunctionsDetailState _value;
  // ignore: unused_field
  final $Res Function(FunctionsDetailState) _then;
}

/// @nodoc
abstract class _$$InitialCopyWith<$Res> {
  factory _$$InitialCopyWith(_$Initial value, $Res Function(_$Initial) then) =
      __$$InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialCopyWithImpl<$Res>
    extends _$FunctionsDetailStateCopyWithImpl<$Res>
    implements _$$InitialCopyWith<$Res> {
  __$$InitialCopyWithImpl(_$Initial _value, $Res Function(_$Initial) _then)
      : super(_value, (v) => _then(v as _$Initial));

  @override
  _$Initial get _value => super._value as _$Initial;
}

/// @nodoc

class _$Initial implements Initial {
  const _$Initial();

  @override
  String toString() {
    return 'FunctionsDetailState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(String result) loadingSuccess,
    required TResult Function(FunctionsFailure functionsFailure) loadingFailure,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Initial value) initial,
    required TResult Function(Loading value) loading,
    required TResult Function(LoadingSuccess value) loadingSuccess,
    required TResult Function(LoadingFailure value) loadingFailure,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class Initial implements FunctionsDetailState {
  const factory Initial() = _$Initial;
}

/// @nodoc
abstract class _$$LoadingCopyWith<$Res> {
  factory _$$LoadingCopyWith(_$Loading value, $Res Function(_$Loading) then) =
      __$$LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingCopyWithImpl<$Res>
    extends _$FunctionsDetailStateCopyWithImpl<$Res>
    implements _$$LoadingCopyWith<$Res> {
  __$$LoadingCopyWithImpl(_$Loading _value, $Res Function(_$Loading) _then)
      : super(_value, (v) => _then(v as _$Loading));

  @override
  _$Loading get _value => super._value as _$Loading;
}

/// @nodoc

class _$Loading implements Loading {
  const _$Loading();

  @override
  String toString() {
    return 'FunctionsDetailState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(String result) loadingSuccess,
    required TResult Function(FunctionsFailure functionsFailure) loadingFailure,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Initial value) initial,
    required TResult Function(Loading value) loading,
    required TResult Function(LoadingSuccess value) loadingSuccess,
    required TResult Function(LoadingFailure value) loadingFailure,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class Loading implements FunctionsDetailState {
  const factory Loading() = _$Loading;
}

/// @nodoc
abstract class _$$LoadingSuccessCopyWith<$Res> {
  factory _$$LoadingSuccessCopyWith(
          _$LoadingSuccess value, $Res Function(_$LoadingSuccess) then) =
      __$$LoadingSuccessCopyWithImpl<$Res>;
  $Res call({String result});
}

/// @nodoc
class __$$LoadingSuccessCopyWithImpl<$Res>
    extends _$FunctionsDetailStateCopyWithImpl<$Res>
    implements _$$LoadingSuccessCopyWith<$Res> {
  __$$LoadingSuccessCopyWithImpl(
      _$LoadingSuccess _value, $Res Function(_$LoadingSuccess) _then)
      : super(_value, (v) => _then(v as _$LoadingSuccess));

  @override
  _$LoadingSuccess get _value => super._value as _$LoadingSuccess;

  @override
  $Res call({
    Object? result = freezed,
  }) {
    return _then(_$LoadingSuccess(
      result == freezed
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadingSuccess implements LoadingSuccess {
  const _$LoadingSuccess(this.result);

  @override
  final String result;

  @override
  String toString() {
    return 'FunctionsDetailState.loadingSuccess(result: $result)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadingSuccess &&
            const DeepCollectionEquality().equals(other.result, result));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(result));

  @JsonKey(ignore: true)
  @override
  _$$LoadingSuccessCopyWith<_$LoadingSuccess> get copyWith =>
      __$$LoadingSuccessCopyWithImpl<_$LoadingSuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(String result) loadingSuccess,
    required TResult Function(FunctionsFailure functionsFailure) loadingFailure,
  }) {
    return loadingSuccess(result);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
  }) {
    return loadingSuccess?.call(result);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loadingSuccess != null) {
      return loadingSuccess(result);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Initial value) initial,
    required TResult Function(Loading value) loading,
    required TResult Function(LoadingSuccess value) loadingSuccess,
    required TResult Function(LoadingFailure value) loadingFailure,
  }) {
    return loadingSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
  }) {
    return loadingSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loadingSuccess != null) {
      return loadingSuccess(this);
    }
    return orElse();
  }
}

abstract class LoadingSuccess implements FunctionsDetailState {
  const factory LoadingSuccess(final String result) = _$LoadingSuccess;

  String get result => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  _$$LoadingSuccessCopyWith<_$LoadingSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$LoadingFailureCopyWith<$Res> {
  factory _$$LoadingFailureCopyWith(
          _$LoadingFailure value, $Res Function(_$LoadingFailure) then) =
      __$$LoadingFailureCopyWithImpl<$Res>;
  $Res call({FunctionsFailure functionsFailure});

  $FunctionsFailureCopyWith<$Res> get functionsFailure;
}

/// @nodoc
class __$$LoadingFailureCopyWithImpl<$Res>
    extends _$FunctionsDetailStateCopyWithImpl<$Res>
    implements _$$LoadingFailureCopyWith<$Res> {
  __$$LoadingFailureCopyWithImpl(
      _$LoadingFailure _value, $Res Function(_$LoadingFailure) _then)
      : super(_value, (v) => _then(v as _$LoadingFailure));

  @override
  _$LoadingFailure get _value => super._value as _$LoadingFailure;

  @override
  $Res call({
    Object? functionsFailure = freezed,
  }) {
    return _then(_$LoadingFailure(
      functionsFailure == freezed
          ? _value.functionsFailure
          : functionsFailure // ignore: cast_nullable_to_non_nullable
              as FunctionsFailure,
    ));
  }

  @override
  $FunctionsFailureCopyWith<$Res> get functionsFailure {
    return $FunctionsFailureCopyWith<$Res>(_value.functionsFailure, (value) {
      return _then(_value.copyWith(functionsFailure: value));
    });
  }
}

/// @nodoc

class _$LoadingFailure implements LoadingFailure {
  const _$LoadingFailure(this.functionsFailure);

  @override
  final FunctionsFailure functionsFailure;

  @override
  String toString() {
    return 'FunctionsDetailState.loadingFailure(functionsFailure: $functionsFailure)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadingFailure &&
            const DeepCollectionEquality()
                .equals(other.functionsFailure, functionsFailure));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(functionsFailure));

  @JsonKey(ignore: true)
  @override
  _$$LoadingFailureCopyWith<_$LoadingFailure> get copyWith =>
      __$$LoadingFailureCopyWithImpl<_$LoadingFailure>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(String result) loadingSuccess,
    required TResult Function(FunctionsFailure functionsFailure) loadingFailure,
  }) {
    return loadingFailure(functionsFailure);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
  }) {
    return loadingFailure?.call(functionsFailure);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String result)? loadingSuccess,
    TResult Function(FunctionsFailure functionsFailure)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loadingFailure != null) {
      return loadingFailure(functionsFailure);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(Initial value) initial,
    required TResult Function(Loading value) loading,
    required TResult Function(LoadingSuccess value) loadingSuccess,
    required TResult Function(LoadingFailure value) loadingFailure,
  }) {
    return loadingFailure(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
  }) {
    return loadingFailure?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(Initial value)? initial,
    TResult Function(Loading value)? loading,
    TResult Function(LoadingSuccess value)? loadingSuccess,
    TResult Function(LoadingFailure value)? loadingFailure,
    required TResult orElse(),
  }) {
    if (loadingFailure != null) {
      return loadingFailure(this);
    }
    return orElse();
  }
}

abstract class LoadingFailure implements FunctionsDetailState {
  const factory LoadingFailure(final FunctionsFailure functionsFailure) =
      _$LoadingFailure;

  FunctionsFailure get functionsFailure => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  _$$LoadingFailureCopyWith<_$LoadingFailure> get copyWith =>
      throw _privateConstructorUsedError;
}
