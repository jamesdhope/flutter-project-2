part of 'functions_detail_bloc.dart';

@freezed
abstract class FunctionsDetailEvent with _$FunctionsDetailEvent {
  const factory FunctionsDetailEvent.started(CloudFunction cloudFunction) =
      _Started;
}
