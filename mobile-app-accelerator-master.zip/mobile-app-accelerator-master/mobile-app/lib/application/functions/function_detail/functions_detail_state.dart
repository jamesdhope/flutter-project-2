part of 'functions_detail_bloc.dart';

@freezed
abstract class FunctionsDetailState with _$FunctionsDetailState {
  const factory FunctionsDetailState.initial() = Initial;

  const factory FunctionsDetailState.loading() = Loading;

  const factory FunctionsDetailState.loadingSuccess(String result) =
      LoadingSuccess;

  const factory FunctionsDetailState.loadingFailure(
      FunctionsFailure functionsFailure) = LoadingFailure;
}
