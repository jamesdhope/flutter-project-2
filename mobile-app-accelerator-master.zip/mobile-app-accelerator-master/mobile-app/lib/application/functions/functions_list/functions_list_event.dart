part of 'functions_list_bloc.dart';

@freezed
abstract class FunctionsListEvent with _$FunctionsListEvent {
  const factory FunctionsListEvent.started() = _Started;
}
