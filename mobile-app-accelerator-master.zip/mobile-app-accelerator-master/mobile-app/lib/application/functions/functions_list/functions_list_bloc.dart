import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/domain/functions/functions_failure.dart';
import 'package:iot/infrastructure/functions/file_functions_repository.dart';

part 'functions_list_bloc.freezed.dart';
part 'functions_list_event.dart';
part 'functions_list_state.dart';

@injectable
class FunctionsListBloc extends Bloc<FunctionsListEvent, FunctionsListState> {
  // TODO: use ionterface
  final FunctionsRepository _functionsRepository;

  FunctionsListBloc(this._functionsRepository)
      : super(FunctionsListState.initial()) {
    on<FunctionsListEvent>(_onEvent);
  }

  @override
  FunctionsListState get initialState => const FunctionsListState.initial();

  void _onEvent(
      FunctionsListEvent event, Emitter<FunctionsListState> emit) async {
    await event.map(
      started: (e) async {
        emit(FunctionsListState.loading());
        final failureOrFunctionsList =
            await _functionsRepository.getFunctionsList();

        failureOrFunctionsList.fold(
          (failure) => null,
          (functionsList) => emit(
            FunctionsListState.loadingSuccess(functionsList),
          ),
        );
      },
    );
  }
}
