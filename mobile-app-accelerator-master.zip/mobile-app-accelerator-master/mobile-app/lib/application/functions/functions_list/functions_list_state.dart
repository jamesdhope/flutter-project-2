part of 'functions_list_bloc.dart';

@freezed
abstract class FunctionsListState with _$FunctionsListState {
  const factory FunctionsListState.initial() = Initial;

  const factory FunctionsListState.loading() = Loading;

  const factory FunctionsListState.loadingSuccess(
      List<CloudFunction> functions) = LoadingSuccess;

  const factory FunctionsListState.loadingFailure(
      FunctionsFailure functionsFailure) = LoadingFailure;
}
