import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/domain/auth/auth_failure.dart';
import 'package:iot/domain/auth/i_auth_facade.dart';

part 'sign_in_form_bloc.freezed.dart';

part 'sign_in_form_event.dart';

part 'sign_in_form_state.dart';

@injectable
class SignInFormBloc extends Bloc<SignInFormEvent, SignInFormState> {
  final IAuthFacade _authFacade;

  SignInFormBloc(this._authFacade) : super(SignInFormState.initial()) {
    on<SignInFormEvent>(_onEvent);
  }

  @override
  SignInFormState get initialState => SignInFormState.initial();

  void _onEvent(SignInFormEvent event, Emitter<SignInFormState> emit) async {
    await event.map(
      signInWithIbmButtonClicked: (e) async {
        final failureOrUnit = await _authFacade.signInWithIbmAppId(e.context);

        emit(
          state.copyWith(
            authFailureOrSuccessOption: some(failureOrUnit),
          ),
        );
      },
    );
  }
}
