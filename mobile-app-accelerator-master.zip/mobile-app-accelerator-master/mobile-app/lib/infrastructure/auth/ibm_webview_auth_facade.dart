import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_keychain/flutter_keychain.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/domain/auth/auth_failure.dart';
import 'package:iot/domain/auth/i_auth_facade.dart';
import 'package:oauth_webauth/oauth_webauth.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

@Injectable(as: IAuthFacade)
class IbmWebviewAuthFacade implements IAuthFacade {
  @override
  Future<String?> getSignedInJwt() async {
    return await FlutterKeychain.get(key: 'accessToken');
  }

  @override
  Future<Either<AuthFailure, Unit>> signInWithIbmAppId(
      BuildContext context) async {
    var cancelled = false;
    var error = false;
    print("OAuth Flow");

    await OAuthWebScreen.start(
        context: context,
        authorizationEndpointUrl:
            dotenv.env['authorizationEndpointUrl'].toString(),
        tokenEndpointUrl: dotenv.env['tokenEndpointUrl'].toString(),
        clientId: dotenv.env['clientId'].toString(),
        clientSecret: dotenv.env['clientSecret'].toString(),
        redirectUrl: dotenv.env['redirectUrl'].toString(),
        scopes: [],
        promptValues: const ['login'],
        loginHint: 'johndoe@mail.com',
        onCertificateValidate: (certificate) {
          /// TODO
          /// Do certificate validations here
          /// If false is returned then a CertificateException() will be thrown
          return true;
        },
        refreshBtnVisible: false,
        clearCacheBtnVisible: true,
        onSuccess: (credentials) async {
          FlutterKeychain.put(
              key: 'accessToken', value: credentials.accessToken);
          if (credentials.refreshToken != null) {
            FlutterKeychain.put(
                key: 'refreshToken', value: credentials.refreshToken!);
          }
        },
        onError: (error) {
          error = true;
        },
        onCancel: () {
          cancelled = true;
        });

    if (cancelled) return left(AuthFailure.cancelledByUser());
    if (error == true) return left(AuthFailure.serverError());

    return right(unit);
  }

  @override
  Future<void> signOut() async {
    await FlutterKeychain.clear();
  }

  @override
  Future<bool> get isAuthenticated async => (await getSignedInJwt()) != null;
}
