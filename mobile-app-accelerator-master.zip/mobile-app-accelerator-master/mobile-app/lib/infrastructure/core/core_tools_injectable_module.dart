import 'package:flutter_keychain/flutter_keychain.dart';
import 'package:injectable/injectable.dart';

@module
abstract class CoreToolsInjectableModule {
  FlutterKeychain get flutterKeyChain => FlutterKeychain();
}
