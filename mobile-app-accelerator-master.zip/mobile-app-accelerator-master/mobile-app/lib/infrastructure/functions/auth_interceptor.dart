import 'package:dio/dio.dart';
import 'package:flutter_keychain/flutter_keychain.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/domain/auth/i_auth_facade.dart';
import 'package:iot/domain/core/errors.dart';

@injectable
class AuthInterceptor extends Interceptor {
  final IAuthFacade _authFacade;

  Future<String> get bearerToken async {
    final token = await _authFacade.getSignedInJwt();
    if (token == null) {
      throw UnexpectedValueError;
    }

    return 'Bearer $token';
  }

  AuthInterceptor(this._authFacade);

  @override
  Future onRequest(RequestOptions options,
      RequestInterceptorHandler handler,) async {
    options.headers.addAll({
      'Authorization': await bearerToken,
    });

    return super.onRequest(options, handler);
  }

  @override
  Future onError(error, handler) async {
    await FlutterKeychain.clear();
    // TODO: check error message from server (does it indeed have a message that says "invalid jwt"?
    if (error.response?.statusCode == 401 &&
        error.response?.data["message"] == "Invalid JWT") {
      final refreshToken = await FlutterKeychain.get(key: "refreshToken");
      // TODO: check if there is a refresh token
      // TODO: request new access token
    }
  }
}
