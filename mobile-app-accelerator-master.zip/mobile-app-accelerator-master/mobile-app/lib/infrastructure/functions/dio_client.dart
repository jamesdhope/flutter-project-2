import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/infrastructure/functions/auth_interceptor.dart';

@module
abstract class DioClient {
  @preResolve
  @Named('CloudFunctionsClient')
  Future<Dio> initDataClient(AuthInterceptor _authInterceptor) async {
    final _dio = Dio();

    _dio.interceptors.add(_authInterceptor);

    _dio.options.baseUrl = 'https://90009e95.eu-gb.apigw.appdomain.cloud/';

    return _dio;
  }
}
