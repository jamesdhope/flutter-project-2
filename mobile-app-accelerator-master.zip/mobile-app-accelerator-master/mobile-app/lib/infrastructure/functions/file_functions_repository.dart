import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import "package:flutter/services.dart" as s;
import 'package:injectable/injectable.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/domain/functions/functions_failure.dart';
import 'package:iot/domain/functions/i_functions_repository.dart';
import "package:yaml/yaml.dart";

@Injectable(as: IFunctionsRepository)
class FunctionsRepository implements IFunctionsRepository {
  final Dio _client;

  FunctionsRepository(@Named('CloudFunctionsClient') this._client);

  FutureOr<Either<FunctionsFailure, List<CloudFunction>>>
      getFunctionsList() async {
    final data = await s.rootBundle.loadString('functions/functions_list.yaml');
    final parsedYaml = loadYaml(data);

    final listOfUnparsedFunctions = parsedYaml['functions'] as List<dynamic>;

    final parsedFunctions = listOfUnparsedFunctions
        .map((unparsedFunction) => CloudFunction(
            endpoint: unparsedFunction['endpoint'],
            name: unparsedFunction['name']))
        .toList();

    return right(parsedFunctions);
  }

  Future<Either<FunctionsFailure, String>> callFunction(
      CloudFunction cloudFunction) async {
    try {
      final result = await _client.get(cloudFunction.endpoint);
      return right(result.data.toString());
    } on DioError catch (e, s) {
      return left(FunctionsFailure.unableToFetch());
    }
  }
}
