import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:iot/injection.dart';
import 'package:iot/presentation/app_widget.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  configureInjection(Environment.prod);
  await dotenv.load(fileName: ".env");
  runApp(AppWidget());
}
