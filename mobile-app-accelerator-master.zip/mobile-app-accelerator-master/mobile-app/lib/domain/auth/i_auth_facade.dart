import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:iot/domain/auth/auth_failure.dart';

abstract class IAuthFacade {
  Future<bool> get isAuthenticated;

  Future<String?> getSignedInJwt();

  Future<Either<AuthFailure, Unit>> signInWithIbmAppId(BuildContext context);

  Future<void> signOut();
}
