import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:iot/domain/core/entity.dart';
import 'package:iot/domain/core/value_objects.dart';

part 'user.freezed.dart';

@freezed
class User with _$User implements IEntity {
  const factory User({
    required UniqueId id,
    required String name,
    required String emailAddress,
  }) = _User;
}
