import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:iot/domain/functions/cloud_function.dart';
import 'package:iot/domain/functions/functions_failure.dart';

abstract class IFunctionsRepository {
  FutureOr<Either<FunctionsFailure, List<CloudFunction>>> getFunctionsList();

  Future<Either<FunctionsFailure, String>> callFunction(
      CloudFunction cloudFunction);
}
