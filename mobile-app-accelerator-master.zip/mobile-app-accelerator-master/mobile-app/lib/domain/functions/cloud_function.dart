import 'package:freezed_annotation/freezed_annotation.dart';

part 'cloud_function.freezed.dart';

@freezed
abstract class CloudFunction with _$CloudFunction {
  const factory CloudFunction({
    required String endpoint,
    required String name,
  }) = _CloudFunction;
}
