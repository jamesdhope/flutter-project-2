import 'package:dartz/dartz.dart';
import 'package:iot/domain/core/failures.dart';
import 'package:iot/domain/core/value_objects.dart';
import 'package:iot/domain/core/value_validators.dart';

class FunctionsBody extends ValueObject<String> {
  @override
  final Either<ValueFailure<String>, String> value;

  static const maxLength = 1000;

  factory FunctionsBody(String input) {
    assert(input != null);
    return FunctionsBody._(
      validateMaxStringLength(input, maxLength).flatMap(validateStringNotEmpty),
    );
  }

  const FunctionsBody._(this.value);
}
