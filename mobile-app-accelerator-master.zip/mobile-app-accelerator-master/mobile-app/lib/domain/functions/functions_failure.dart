import 'package:freezed_annotation/freezed_annotation.dart';

part 'functions_failure.freezed.dart';

@freezed
abstract class FunctionsFailure with _$FunctionsFailure {
  const factory FunctionsFailure.unableToFetch() = UnableToFetch;
}
