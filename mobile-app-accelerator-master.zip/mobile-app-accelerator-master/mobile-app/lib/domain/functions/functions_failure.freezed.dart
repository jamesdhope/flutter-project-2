// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'functions_failure.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$FunctionsFailure {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unableToFetch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unableToFetch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unableToFetch,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(UnableToFetch value) unableToFetch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(UnableToFetch value)? unableToFetch,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(UnableToFetch value)? unableToFetch,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FunctionsFailureCopyWith<$Res> {
  factory $FunctionsFailureCopyWith(
          FunctionsFailure value, $Res Function(FunctionsFailure) then) =
      _$FunctionsFailureCopyWithImpl<$Res>;
}

/// @nodoc
class _$FunctionsFailureCopyWithImpl<$Res>
    implements $FunctionsFailureCopyWith<$Res> {
  _$FunctionsFailureCopyWithImpl(this._value, this._then);

  final FunctionsFailure _value;
  // ignore: unused_field
  final $Res Function(FunctionsFailure) _then;
}

/// @nodoc
abstract class _$$UnableToFetchCopyWith<$Res> {
  factory _$$UnableToFetchCopyWith(
          _$UnableToFetch value, $Res Function(_$UnableToFetch) then) =
      __$$UnableToFetchCopyWithImpl<$Res>;
}

/// @nodoc
class __$$UnableToFetchCopyWithImpl<$Res>
    extends _$FunctionsFailureCopyWithImpl<$Res>
    implements _$$UnableToFetchCopyWith<$Res> {
  __$$UnableToFetchCopyWithImpl(
      _$UnableToFetch _value, $Res Function(_$UnableToFetch) _then)
      : super(_value, (v) => _then(v as _$UnableToFetch));

  @override
  _$UnableToFetch get _value => super._value as _$UnableToFetch;
}

/// @nodoc

class _$UnableToFetch implements UnableToFetch {
  const _$UnableToFetch();

  @override
  String toString() {
    return 'FunctionsFailure.unableToFetch()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$UnableToFetch);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unableToFetch,
  }) {
    return unableToFetch();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unableToFetch,
  }) {
    return unableToFetch?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unableToFetch,
    required TResult orElse(),
  }) {
    if (unableToFetch != null) {
      return unableToFetch();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(UnableToFetch value) unableToFetch,
  }) {
    return unableToFetch(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(UnableToFetch value)? unableToFetch,
  }) {
    return unableToFetch?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(UnableToFetch value)? unableToFetch,
    required TResult orElse(),
  }) {
    if (unableToFetch != null) {
      return unableToFetch(this);
    }
    return orElse();
  }
}

abstract class UnableToFetch implements FunctionsFailure {
  const factory UnableToFetch() = _$UnableToFetch;
}
