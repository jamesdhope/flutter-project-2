import 'package:iot/domain/core/value_objects.dart';

abstract class IEntity {
  UniqueId get id;
}
