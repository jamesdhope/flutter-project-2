// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

import 'package:dio/dio.dart' as _i9;
import 'package:flutter_keychain/flutter_keychain.dart' as _i3;
import 'package:get_it/get_it.dart' as _i1;
import 'package:injectable/injectable.dart' as _i2;

import 'application/auth/auth_bloc.dart' as _i7;
import 'application/auth/sign_in_form/sign_in_form_bloc.dart' as _i6;
import 'application/functions/function_detail/functions_detail_bloc.dart'
    as _i11;
import 'application/functions/functions_list/functions_list_bloc.dart' as _i12;
import 'domain/auth/i_auth_facade.dart' as _i4;
import 'infrastructure/auth/ibm_webview_auth_facade.dart' as _i5;
import 'infrastructure/core/core_tools_injectable_module.dart' as _i13;
import 'infrastructure/functions/auth_interceptor.dart' as _i8;
import 'infrastructure/functions/dio_client.dart' as _i14;
import 'infrastructure/functions/file_functions_repository.dart'
    as _i10; // ignore_for_file: unnecessary_lambdas

// ignore_for_file: lines_longer_than_80_chars
/// initializes the registration of provided dependencies inside of [GetIt]
Future<_i1.GetIt> $initGetIt(_i1.GetIt get,
    {String? environment, _i2.EnvironmentFilter? environmentFilter}) async {
  final gh = _i2.GetItHelper(get, environment, environmentFilter);
  final coreToolsInjectableModule = _$CoreToolsInjectableModule();
  final dioClient = _$DioClient();
  gh.factory<_i3.FlutterKeychain>(
      () => coreToolsInjectableModule.flutterKeyChain);
  gh.factory<_i4.IAuthFacade>(() => _i5.IbmWebviewAuthFacade());
  gh.factory<_i6.SignInFormBloc>(
      () => _i6.SignInFormBloc(get<_i4.IAuthFacade>()));
  gh.factory<_i7.AuthBloc>(() => _i7.AuthBloc(get<_i4.IAuthFacade>()));
  gh.factory<_i8.AuthInterceptor>(
      () => _i8.AuthInterceptor(get<_i4.IAuthFacade>()));
  await gh.factoryAsync<_i9.Dio>(
      () => dioClient.initDataClient(get<_i8.AuthInterceptor>()),
      instanceName: 'CloudFunctionsClient',
      preResolve: true);
  gh.factory<_i10.FunctionsRepository>(() => _i10.FunctionsRepository(
      get<_i9.Dio>(instanceName: 'CloudFunctionsClient')));
  gh.factory<_i11.FunctionsDetailBloc>(
      () => _i11.FunctionsDetailBloc(get<_i10.FunctionsRepository>()));
  gh.factory<_i12.FunctionsListBloc>(
      () => _i12.FunctionsListBloc(get<_i10.FunctionsRepository>()));
  return get;
}

class _$CoreToolsInjectableModule extends _i13.CoreToolsInjectableModule {}

class _$DioClient extends _i14.DioClient {}
